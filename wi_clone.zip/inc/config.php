<?php

//MARK: SITE VARIABLES

$SITE_NAME = "wi";

$con = mysqli_connect("localhost","ENTER YOUR USERNAME","ENTER YOUR PASSWORD","wi_db");


?>